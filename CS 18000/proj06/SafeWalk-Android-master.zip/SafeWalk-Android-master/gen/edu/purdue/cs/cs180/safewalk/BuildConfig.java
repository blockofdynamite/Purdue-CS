/** Automatically generated file. DO NOT MODIFY */
package edu.purdue.cs.cs180.safewalk;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}