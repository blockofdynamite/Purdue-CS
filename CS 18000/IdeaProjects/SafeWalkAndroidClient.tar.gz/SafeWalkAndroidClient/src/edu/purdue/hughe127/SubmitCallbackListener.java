package edu.purdue.hughe127;

public interface SubmitCallbackListener {
	
	public void onSubmit();

}
