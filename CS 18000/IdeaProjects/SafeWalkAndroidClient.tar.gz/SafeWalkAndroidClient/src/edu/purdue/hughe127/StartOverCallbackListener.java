package edu.purdue.hughe127;

public interface StartOverCallbackListener {
	public void onStartOver();
}
