/**
 * Write a Java program to print all the numbers between 1 and 25000 (inclusive) that are both
 * perfect squares and cubes
 *
 * Hint: There are only five such numbers and one of them is 1
 *
 * @author hughe127 - Jeff Hughes
 * @date 19 February 2015
 * @class CS Bridge UTA "Test"
 */

public class PerfectSquareCube {

    public static boolean isPerfectSquare(int n) {
        //only want natural numbers (AKA integers > 0)
        int test = (int) Math.sqrt(n);
        return (test * test == n);
    }

    private static boolean isPerfectCube(int n) {
        //only want natural numbers (AKA integers > 0)
        int test = (int) (Math.cbrt(n));
        return (test * test * test == n);
    }

    public static void main(String[] args) {
        for (int i = 1; i < 25000; i++) {
            //Test if the number is a perfect square
            if (isPerfectSquare(i)) {
                //Test if the number is a perfect cube
                if (isPerfectCube(i)) {
                    System.out.println(i);
                }
            }
        }
    }
}
