import static org.junit.Assert.*;

public class CustomerTest {

    @org.junit.Test
    public void testCompare1() throws Exception {
        Camera c1 = new Camera(true, true, true, "Refurbished", 100.00, 5);
        Camera c2 = new Camera(true, true, true, "New", 100.00, 5);
        assertEquals("compare() isn't working properly", Customer.compare(c1, c2), 2);
    }

    @org.junit.Test
    public void testCompare2() throws Exception {
        Camera c1 = new Camera(true, true, true, "New", 100.00, 5);
        Camera c2 = new Camera(true, true, true, "New", 100.00, 5);
        assertEquals("compare() isn't working properly", Customer.compare(c1, c2), 0);
    }

    @org.junit.Test
    public void testCompare3() throws Exception {
        Camera c1 = new Camera(true, true, true, "New", 100.00, 3);
        Camera c2 = new Camera(true, true, true, "New", 100.00, 5);
        assertEquals("compare() isn't working properly", Customer.compare(c1, c2), 2);
    }

    @org.junit.Test
    public void testCompare4() throws Exception {
        Camera c1 = new Camera(true, true, true, "New", 100.00, 5);
        Camera c2 = new Camera(true, false, true, "New", 100.00, 5);
        assertEquals("compare() isn't working properly", Customer.compare(c1, c2), 1);
    }

    @org.junit.Test
    public void testCompare5() throws Exception {
        Camera c1 = new Camera(true, true, true, "New", 50.00, 5);
        Camera c2 = new Camera(true, true, true, "New", 100.00, 5);
        assertEquals("compare() isn't working properly", Customer.compare(c1, c2), 1);
    }
}