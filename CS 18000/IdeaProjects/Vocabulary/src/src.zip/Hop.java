/**
 * Created by jeff on 10/5/14.
 */
public class Hop {
    public Hop() {
        System.out.println("Hop");
    }
    public static void main(String[] args) {
        Jump test = new Jump();
    }
}
