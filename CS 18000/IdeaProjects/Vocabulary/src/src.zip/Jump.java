/**
 * Created by jeff on 10/5/14.
 */
public class Jump extends Skip {
    public Jump() {
        System.out.println("Jump");
    }

}
