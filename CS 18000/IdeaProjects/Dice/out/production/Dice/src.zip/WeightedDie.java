class WeightedDie extends Die {
    public int roll() {
        if (Math.random() > .5) {
            return 6;
        }

        else {
            return super.roll();
        }
    }
}
