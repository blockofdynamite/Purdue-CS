public class Song{
	// TODO Task 2
	// define any fields needed
	// to represent a song
	// and the getters, setters and constructors
}
