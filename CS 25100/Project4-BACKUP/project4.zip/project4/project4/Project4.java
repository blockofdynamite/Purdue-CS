class Command {
	// TODO Task 1
	// define a class to represent all the
	// commands from the user input
	public int getCommandType() {
		return 0;
	}
}

public class Project4 {

	// get the input from the user
	// parse the input
	// construct a Command object
	// and return it
	public static Command getNextCommand() {
		// TODO Task 1

		return null;
	}

	public static void main(String[] args) {
		SongCollection songCollection = new SongCollection();

		Command command = getNextCommand();
		while (null != command) {
			switch (command.getCommandType()) {
			// TODO Task1

			// case 1:
			// ......
			// break;

			// case 2:
			// ......
			// break;

			default:
				break;
			}
			command = getNextCommand();
			// if command.getCommandType = Command.END
			// System.exit(0);
		}

	}
}
