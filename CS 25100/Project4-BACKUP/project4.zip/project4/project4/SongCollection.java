import java.util.List;

public class SongCollection {
	// TODO Task 2
	// Organize all the songs here

	// add a song at date, with the name S{date}
	// and default L and N
	public void addSong(int date){
		// TODO Task 3

	}

	// delete the n songs of lowest priorities
	public void deleteSong(int n) {
		// TODO Task 3
	}

	// update song named by songName
	public void updateSong(String songName, int deltaN, int deltaL) {
		// TODO Task 3
	}

	// return the 3 most popular songs in the return value
	// with the most popular at index 0
	//      the second popular at index 1
	//      the third popular at index 2
	public List<Song> popular() {
		// TODO Task 3
		return null;
	}

	// return the popularity
	// of the most and least popular songs
	// the 0th integer in the returned object
	// should be the popularity of the most popular song
	// and the 1st integer should be the popularity of
	// the least popular song 
	public List<Integer> minMax() {
		// TODO Task 3
		return null;
	}
}