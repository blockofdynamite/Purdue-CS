import java.util.ArrayList;
import java.util.Scanner;


public class Project2Part1 {
	public static void main(String args[]) {
		/**
		 * TODO: PART1
		 */
	}
}